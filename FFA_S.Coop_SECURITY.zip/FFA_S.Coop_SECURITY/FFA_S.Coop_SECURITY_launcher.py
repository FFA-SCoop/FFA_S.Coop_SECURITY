import os
import sys
import shutil
import argparse
import importlib.util
import PyInstaller.__main__  # Importa PyInstaller para su uso en la creación de ejecutables

# Lista de dependencias necesarias para el script
DEPENDENCIAS = [
    "tkinter",  # GUI
    "cryptography" # Cifrar contraseñas
]

# Constantes de rutas y nombres de archivos
RUTA_ICONO = "C:\\Users\\gerar\\Desktop\\PROYECTO_FFA_S_Coop\\CIFRADO_FFA_S_Coop\\FUNCIONAL\\FFA_S.Coop_LOGO.ico"
RUTA_LOGO = "C:\\Users\\gerar\\Desktop\\PROYECTO_FFA_S_Coop\\CIFRADO_FFA_S_Coop\\FUNCIONAL\\FFA_S.Coop_LOGO.ico"
ARCHIVO_PYTHON = "C:\\Users\\gerar\\Desktop\\PROYECTO_FFA_S_Coop\\CIFRADO_FFA_S_Coop\\FUNCIONAL\\FFA_S.Coop_SECURITY.py"
NOMBRE_EJECUTABLE = "FFA_S.Coop_SECURITY"
DIRECTORIO_EJECUTABLE = "build_output"  # Directorio de salida para el ejecutable

# Función para instalar dependencias
def instalar_dependencias():
    for dependencia in DEPENDENCIAS:
        # Verificar si la dependencia está instalada
        spec = importlib.util.find_spec(dependencia)
        if spec is None:
            # Si el paquete no está instalado, instalarlo
            try:
                comando = f"{sys.executable} -m pip install {dependencia}"
                codigo_salida = os.system(comando)
                if codigo_salida == 0:
                    print(f"La dependencia '{dependencia}' se ha instalado correctamente.")
                else:
                    print(f"No se pudo instalar la dependencia '{dependencia}'. Código de salida: {codigo_salida}")
                    sys.exit(1)
            except Exception as e:
                print(f"Ocurrió un error inesperado al instalar '{dependencia}': {e}")
                sys.exit(1)
        else:
            print(f"La dependencia '{dependencia}' ya está instalada.")

# Función para copiar el ejecutable al escritorio
def copiar_ejecutable_al_escritorio():
    # Ruta del escritorio del usuario
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    # Ruta completa del ejecutable
    ejecutable_path = os.path.join(DIRECTORIO_EJECUTABLE, NOMBRE_EJECUTABLE + ".exe")
    
    # Verifica si el ejecutable existe
    if not os.path.exists(ejecutable_path):
        print(f"No se pudo encontrar el ejecutable en {ejecutable_path}.")
        return
    
    # Copia el ejecutable al escritorio
    try:
        # Ruta del destino en el escritorio
        destino = os.path.join(desktop_path, NOMBRE_EJECUTABLE + ".exe")
        shutil.copy2(ejecutable_path, destino)
        print(f"Ejecutable copiado al escritorio en {destino}.")
    except PermissionError:
        print("Error: Permisos insuficientes para copiar el ejecutable al escritorio.")
    except FileExistsError:
        print("Error: El ejecutable ya existe en el escritorio.")
    except Exception as e:
        print(f"No se pudo copiar el ejecutable al escritorio: {e}")

# Función para crear el ejecutable usando PyInstaller
def crear_ejecutable():
    # Verifica la existencia de los archivos
    if not os.path.exists(ARCHIVO_PYTHON):
        print(f"El archivo de script {ARCHIVO_PYTHON} no existe.")
        sys.exit(1)

    if not os.path.exists(RUTA_ICONO):
        print(f"El archivo de icono {RUTA_ICONO} no existe.")
        sys.exit(1)

    # Llama a PyInstaller para crear el ejecutable
    PyInstaller.__main__.run([
        ARCHIVO_PYTHON,
        '--onefile',  # Crea un solo archivo ejecutable
        '--windowed',  # Crea una aplicación GUI (sin consola)
        '--icon', RUTA_ICONO,  # Agrega el icono a la aplicación
        '--name', NOMBRE_EJECUTABLE,  # Nombre del archivo ejecutable
        f'--add-data={RUTA_LOGO};.',  # Incluye el logo en el ejecutable
        '--distpath', DIRECTORIO_EJECUTABLE,  # Directorio de salida para el ejecutable
    ])

    # Copia el ejecutable al escritorio
    copiar_ejecutable_al_escritorio()

# Función principal
def main():
    # Uso de argparse para manejar argumentos de línea de comandos
    parser = argparse.ArgumentParser(description='Launcher para cifrado y descifrado.')
    
    # Argumento para instalar dependencias
    parser.add_argument('--install-dependencies', action='store_true', help='Instalar dependencias requeridas.')
    
    # Argumento para crear el ejecutable
    parser.add_argument('build', nargs='?', default=None, help='Construir el ejecutable con PyInstaller.')
    
    # Parsear argumentos de línea de comandos
    args = parser.parse_args()
    
    # Instalar dependencias si se especifica
    if args.install_dependencies:
        instalar_dependencias()
    
    # Crear el ejecutable si se especifica
    if args.build:
        crear_ejecutable()

if __name__ == '__main__':
    main()
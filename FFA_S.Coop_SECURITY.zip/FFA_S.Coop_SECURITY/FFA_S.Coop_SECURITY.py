# Autor: NEWTON73
# Fecha: [23/05/2024]
# Descripción: [Algoritmo de cifrado y descifrado por el metodo 'NEWTON73']

import random
import json
import os
import tkinter as tk
from tkinter import simpledialog, filedialog, messagebox
from cryptography.fernet import Fernet
import base64
import hashlib

abc = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789áéíóúàèìòùïüñçÁÉÍÓÚÀÈÌÒÙÏÜÑÇ!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~ \t\n\r\x0b\x0c'

# Caja de permutación para AES
caja_p = [
    0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75,
    2, 7, 12, 17, 22, 27, 32, 37, 42, 47, 52, 57, 62, 67, 72, 77,
    4, 9, 14, 19, 24, 29, 34, 39, 44, 49, 54, 59, 64, 69, 74, 79,
    1, 6, 11, 16, 21, 26, 31, 36, 41, 46, 51, 56, 61, 66, 71, 76,
    3, 8, 13, 18, 23, 28, 33, 38, 43, 48, 53, 58, 63, 68, 73, 78
]

# Caja de sustitución para AES
caja_s = [
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5,
    0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0,
    0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc,
    0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a,
    0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0,
    0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b,
    0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85,
    0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5,
    0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17,
    0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88,
    0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c,
    0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9,
    0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6,
    0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e,
    0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94,
    0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68,
    0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
]

# Función para generar la caja de permutaciones p
def generar_caja_p():
    caja_p = list(range(len(abc)))
    random.shuffle(caja_p)
    return caja_p

# Función para generar la caja de permutaciones s
def generar_caja_s():
    caja_s = list(range(len(abc)))
    random.shuffle(caja_s)
    return caja_s

# Función para guardar las permutaciones en un archivo JSON
def guardar_permutaciones(caja_p, caja_s, archivo="build_output/permutaciones.json"):
    permutaciones = {"caja_p": caja_p, "caja_s": caja_s}
    with open(archivo, "w") as f:
        json.dump(permutaciones, f)

# Función para cargar las permutaciones desde un archivo JSON
def cargar_permutaciones(archivo="build_output/permutaciones.json"):
    with open(archivo, "r") as f:
        permutaciones = json.load(f)
    return permutaciones["caja_p"], permutaciones["caja_s"]

# Función para cifrar una cadena utilizando las cajas de permutaciones
def cifrar(cadena, caja_p, caja_s):
    texto_cifrado = ''
    pos_anterior = 0
    for letra in cadena:
        if letra in abc:
            indice = abc.find(letra)
            p_box_output = caja_p.index((indice + pos_anterior) % len(caja_p))
            s_box_output = caja_s[p_box_output]
            texto_cifrado += abc[s_box_output]
            pos_anterior = p_box_output
        else:
            texto_cifrado += letra
    return texto_cifrado

# Función para descifrar una cadena utilizando las cajas de permutaciones
def descifrar(cadena, caja_p, caja_s):
    texto_descifrado = ''
    pos_anterior = 0
    for letra in cadena:
        if letra in abc:
            indice = abc.find(letra)
            s_box_input = caja_s.index(indice)
            p_box_input = (caja_p[s_box_input] - pos_anterior + len(caja_p)) % len(caja_p)
            texto_descifrado += abc[p_box_input]
            pos_anterior = s_box_input
        else:
            texto_descifrado += letra
    return texto_descifrado

# Función para cifrar el contenido de un archivo
def cifrar_archivo(input_path, output_path, caja_p, caja_s):
    with open(input_path, 'r', encoding='utf-8') as f:
        contenido = f.read()
    contenido_cifrado = cifrar(contenido, caja_p, caja_s)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(contenido_cifrado)

# Función para descifrar el contenido de un archivo
def descifrar_archivo(input_path, output_path, caja_p, caja_s):
    with open(input_path, 'r', encoding='utf-8') as f:
        contenido = f.read()
    contenido_descifrado = descifrar(contenido, caja_p, caja_s)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(contenido_descifrado)

# Función para generar una clave Fernet a partir de una contraseña
def generar_clave(password):
    key = hashlib.sha256(password.encode()).digest()
    return base64.urlsafe_b64encode(key[:32])

# Función para cifrar las permutaciones con una clave
def cifrar_permutaciones(password, archivo="build_output/permutaciones.json"):
    clave = generar_clave(password)
    fernet = Fernet(clave)
    with open(archivo, "rb") as f:
        data = f.read()
    data_cifrada = fernet.encrypt(data)
    with open(archivo, "wb") as f:
        f.write(data_cifrada)
    return clave

# Función para descifrar las permutaciones con una clave
def descifrar_permutaciones(clave, archivo="build_output/permutaciones.json"):
    fernet = Fernet(clave)
    with open(archivo, "rb") as f:
        data_cifrada = f.read()
    data_descifrada = fernet.decrypt(data_cifrada)
    # Escribir el archivo descifrado temporalmente
    temp_file = archivo + ".temp"
    with open(temp_file, "wb") as f:
        f.write(data_descifrada)
    # Renombrar el archivo temporal al nombre original
    os.replace(temp_file, archivo)
    return data_descifrada

def main():
    try:
        # Crear el directorio de salida si no existe
        if not os.path.exists("build_output"):
            os.makedirs("build_output")

        root = tk.Tk()
        root.withdraw()

        # Solicitar la acción al usuario
        action = simpledialog.askstring("Acción", "¿Qué desea hacer? (cifrar/descifrar)")

        if action and action.lower() == "cifrar":
            password = simpledialog.askstring("Contraseña", "Ingrese una contraseña:", show='*')

            # Seleccionar archivo de entrada y salida
            input_path = filedialog.askopenfilename(title="Seleccione el archivo a cifrar")
            output_path = filedialog.asksaveasfilename(title="Guardar archivo cifrado como", defaultextension=".txt")

            if not input_path or not output_path:
                messagebox.showerror("Error", "Debe seleccionar archivos válidos.")
                return

            # Generar las cajas de permutaciones
            caja_p = generar_caja_p()
            caja_s = generar_caja_s()

            # Cifrar el archivo y guardar las permutaciones
            cifrar_archivo(input_path, output_path, caja_p, caja_s)
            guardar_permutaciones(caja_p, caja_s)

            # Cifrar las permutaciones y guardar la clave
            clave = cifrar_permutaciones(password)
            with open("build_output/key.key", "wb") as key_file:
                key_file.write(clave)

            messagebox.showinfo("Éxito", f"Archivo cifrado guardado en: {output_path}")

        elif action and action.lower() == "descifrar":
            password = simpledialog.askstring("Contraseña", "Ingrese la contraseña:", show='*')
            key_path = filedialog.askopenfilename(title="Seleccione el archivo de clave", filetypes=[("Key Files", "*.key")])

            if not password or not key_path:
                messagebox.showerror("Error", "Debe proporcionar la contraseña y seleccionar el archivo de clave.")
                return

            with open(key_path, "rb") as key_file:
                clave = key_file.read()

            # Seleccionar archivo de entrada y salida
            input_path = filedialog.askopenfilename(title="Seleccione el archivo a descifrar")
            output_path = filedialog.asksaveasfilename(title="Guardar archivo descifrado como", defaultextension=".txt")

            if not input_path or not output_path:
                messagebox.showerror("Error", "Debe seleccionar archivos válidos.")
                return

            # Descifrar las permutaciones y cargar las cajas
            descifrar_permutaciones(clave)
            caja_p, caja_s = cargar_permutaciones()

            # Descifrar el archivo
            descifrar_archivo(input_path, output_path, caja_p, caja_s)

            # Solo eliminar los archivos si el descifrado fue exitoso
            os.remove("build_output/permutaciones.json")
            os.remove(key_path)

            messagebox.showinfo("Éxito", f"Archivo descifrado guardado en: {output_path}")

        else:
            messagebox.showerror("Error", "Acción no reconocida. Por favor, elija 'cifrar' o 'descifrar'.")

    except Exception as e:
        messagebox.showerror("Error", f"Se produjo un error: {e}")

if __name__ == '__main__':
    main()